# GrocerEase 🛒  

Simple grocery store web app created using HTML, CSS and Javascript to demonstrate the responsive navigation bar.  


![visitors](https://visitor-badge.glitch.me/badge?page_id=sahil-sagwekar2652.sahil-sagwekar2652&left_color=blue&right_color=red)

[![GrocerEase](https://github-readme-stats.vercel.app/api/pin/?username=Shubham185y&repo=GrocerEase&theme=dark)](https://github.com/Shubham185y/GrocerEase)<br/>


## Tech
[![My Skills](https://skillicons.dev/icons?i=html,css,js,github&perline=4)](https://skillicons.dev)

## Screenshots
* Desktop view  


![image](https://user-images.githubusercontent.com/100077254/230788942-512886e5-d7ef-4935-b451-5d2af7f1a8c4.png)
![image](https://user-images.githubusercontent.com/100077254/230788948-f0eaf44c-3791-409e-93ed-d581863fa271.png)
![image](https://user-images.githubusercontent.com/100077254/230788949-94cacebc-8087-4602-ae19-5439f239664f.png)
![image](https://user-images.githubusercontent.com/100077254/230788930-f5ae07b2-7697-4475-88cd-f2502d900bf2.png)

* Mobile view  

![image](https://user-images.githubusercontent.com/100077254/230789004-1aaf9555-4f19-4b23-98ac-a044b86e31b0.png)
![image](https://user-images.githubusercontent.com/100077254/230789005-843cbb8f-10fa-4bc9-9086-7251282d8713.png)

